# OLEDSoftI2C_SH1106
Minimalistic Arduino OLED SH1106 library

Optional fast software I2C
